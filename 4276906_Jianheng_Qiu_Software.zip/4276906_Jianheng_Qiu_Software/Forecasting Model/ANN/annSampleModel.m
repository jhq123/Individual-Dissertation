clc
clear
x=xlsread('Sample Data2','D2:Y51');
y=xlsread('Sample Data2','Z2:Z51');
p=x';t=y';
[pn,ps]=mapminmax(p);
[tn,ts]=mapminmax(t);
net=newff(pn,tn,[45],{'tansig','purelin'},'trainscg');
inputWeights=net.IW{1,1}+0.75;
inputbias=net.b{1}+0.5;
layerWeights=net.LW{2,1}+0.75;
layerbias=net.b{2};
net.trainParam.show=10;
net.trainParam.lr=0.05;
net.trainParam.mc=0.02;
net.trainParam.epochs=1000;
net.trainParam.goal=0.001;
net=train(net,pn,tn);
output1=sim(net,pn);
output2=mapminmax('reverse',output1,ts);
output=roundn(output2,-1);

trainmse=(sum(((t-output)./t).^2))/length(t);
%trainRelativeError=sum(abs((t-output)./t))/length(t);
%trainRMSE=sqrt(sum(((t-output)./t).^2)/length(t));

save net
x1=xlsread('Sample Data2',['D52:Y61']);
y1=xlsread('Sample Data2',['Z52:Z61']);
p2=x1';t2=y1';
p2n=mapminmax('apply',p2,ps);
a2n=sim(net,p2n);
a2=mapminmax('reverse',a2n,ts);
test_out=roundn(a2,-1);

testmse=(sum(((t2-test_out)./t2).^2))/length(t2);
%testRelativeError=sum(abs((t2-test_out)./t2))/length(t2);
%testRMSE=sqrt(sum(((t2-test_out)./t2).^2)/length(t2))
C=[output test_out];
A=[t t2];
allmse=(sum(((A-C)./A).^2))/length(A);
allRelativeError=sum(abs((C-A)./A))/length(A);
allRMSE=sqrt(sum(((A-C)./A).^2)/length(A));
figure
plot(A,'k')
hold on
plot(C,'color',[0.5,0.4,0.6])
hold off