y=xlsread('Sample Data1','Z2:Z51')
Data=y;             
SourceData=Data(1:250,1); 
step=30;                  
TempData=SourceData;
TempData=detrend(TempData);
TrendData=SourceData-TempData;

H=adftest(TempData);
difftime=0;
SaveDiffData=[];
while ~H
SaveDiffData=[SaveDiffData,TempData(1,1)];
TempData=diff(TempData)
difftime=difftime+1;
H=adftest(TempData);
end

u = iddata(TempData);
test = [];
for p = 1:5                      
for q = 1:5                   
m = armax(u,[p q]);        
AIC = aic(m);              
test = [test;p q AIC];
end
end
for k = 1:size(test,1)
if test(k,3) == min(test(:,3)) 
p_test = test(k,1);
q_test = test(k,2);
break;
end
end

TempData=[TempData;zeros(step,1)];
n=iddata(TempData); 
m = armax(u,[p_test q_test]);
                                 %m = armax(u(1:ls),[p_test q_test]);        %armax(p,q),[p_test q_test]
P1=predict(m,n,1);
PreR=P1.OutputData;
PreR=PreR';

if size(SaveDiffData,2)~=0
for index=size(SaveDiffData,2):-1:1
PreR=cumsum([SaveDiffData(index),PreR]);
end
end 
  
mp1=polyfit([1:size(TrendData',2)],TrendData',1);
xt=[];
for j=1:step
xt=[xt,size(TrendData',2)+j];
end
TrendResult=polyval(mp1,xt);
PreData=TrendResult+PreR(size(SourceData',2)+1:size(PreR,2));