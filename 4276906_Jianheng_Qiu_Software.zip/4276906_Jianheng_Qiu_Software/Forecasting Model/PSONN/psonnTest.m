clear 
func_num=1;
D=10;
VRmin=-100;
VRmax=100;
N=40;
Max_Gen=5000;
runs=1;
fhd=str2func('cec14_func');
for i=1
    func_num=i;
    for j=1:runs

    [gbest,gbestval,pop]=myfunc(fhd,D,N,Max_Gen,VRmin,VRmax,func_num);
    xbest(i,:)=gbest;
    fbest(i,j)=gbestval;
    end
    f_mean(i)=mean(fbest(i,j));

end