
%%%%PSO-BPNN

clc
clear

%train_In=xlsread('Sample Data2',['D2:Y51']);
%train_Out=xlsread('Sample Data2',['Z2:Z51']);
AllSamIn=train_In';
AllSamOut=train_Out';

%test_In=xlsread('Sample Data2',['D52:Y61']);
%test_Out=xlsread('Sample Data2',['Z52:Z61']);
AllTestIn=test_In';
AllTestOut=test_Out';

[AllSamInn,AllSamIns]=mapminmax(AllSamIn);
[AllSamOutn,AllSamOuts]=mapminmax(AllSamOut);
TtrainSamIn=AllSamInn;
TtrainSamOut=AllSamOutn;
%global Ptrain;
Ptrain=TtrainSamIn;
%global Ttrain;
Ttrain=TtrainSamOut;

Ptest=mapminmax('apply',AllTestIn,AllSamIns);
indim=22;
hiddennum=45;
outdim=1;

N=50; 
c1=2.0;
c2=2.0;
wmax=1.0;
wmin=0.4; 
itmax=300;       
MaxC=30;      
xmin=-2;xmax=2;
vmin=-0.5;vmax=0.5;
D=(indim+1)*hiddennum+(hiddennum+1)*outdim;

%global net;
net=newff(Ptrain,Ttrain,[hiddennum],{'tansig','purelin'},'trainscg');

for i=1:N
 for j=1:D
  x(i,j)=xmin+(xmax-xmin)*rand;
  v(i,j)=vmin+(vmax-xmin)*rand;
 end
end

for i=1:N
 for j=1:hiddennum
  xwf(j,:)=x(i,((j-1)*indim+1):j*indim);
 end
 for k=1:outdim
  xwb(k,:)=x(i,(indim*hiddennum+1):(indim*hiddennum+hiddennum));
 end
 xb(i,:)=x(i,((indim+1)*hiddennum+1):D);
 xbf=xb(i,1:hiddennum)';
    xbb=xb(i,hiddennum+1:hiddennum+outdim)';
 

 net.IW{1,1}=xwf;
 net.LW{2,1}=xwb; 
 net.b{1}=xbf; 
 net.b{2}=xbb; 
 
 Trainoutput=sim(net,Ptrain); 
 train_outn=mapminmax('reverse',Trainoutput,AllSamOuts);
 Train_out=roundn(train_outn,-1); 

 %train_realerror=Train_out-AllSamOut;
 train_relativeerror = sum(abs((Train_out-AllSamOut)./AllSamOut))/length(AllSamOut);  
 fitness(i)=train_relativeerror;

end


[global_fitness bestindex]=min(fitness);
local_fitness=fitness; 
global_x=x(bestindex,:); 
local_x=x; 
y=x;


for t=1:itmax
 [sort_f,index] = sort(fitness);  
     for k=1:MaxC 
  Nbest = floor(N*0.2); 
     for n=1:Nbest       
          tmpx = x(index(n),:);
          for dim=1:D               
                  cx(dim) = (tmpx(1,dim)-xmin)/(xmax-xmin);    
                  if cx(dim)<=0.4
                              cx(dim)=cx(dim)/0.4;
                         else
                              cx(dim)=(1-cx(dim))/(1-0.4);
                         end                  
                         tmpx(1,dim)=xmin+(xmax-xmin)*cx(dim);     
                  if tmpx(1,dim)>xmax
                       tmpx(1,dim)=xmax;
                  end
                  if tmpx(1,dim)                       tmpx(1,dim)=xmin;
                  end
          end
   
                 for j=1:hiddennum
                      xwf(j,:)=tmpx(1,((j-1)*indim+1):j*indim);
                 end
                 for m=1:outdim
                      xwb(m,:)=tmpx(1,(indim*hiddennum+1):(indim*hiddennum+hiddennum));
                 end
                 xb(1,:)=tmpx(1,((indim+1)*hiddennum+1):D);
                 xbf=xb(1,1:hiddennum)';
                 xbb=xb(1,hiddennum+1:hiddennum+outdim)';

                 net.IW{1,1}=xwf; 
                 net.LW{2,1}=xwb;
                 net.b{1}=xbf; 
                 net.b{2}=xbb; 
                 Trainoutput=sim(net,Ptrain); 
   train_outn=mapminmax('reverse',Trainoutput,AllSamOuts);
   Train_out=roundn(train_outn,-1); 
   %train_realerror=Train_out-AllSamOut;

   train_relativeerror = sum(abs((Train_out-AllSamOut)./AllSamOut))/length(AllSamOut);  
   fitness(i)=train_relativeerror;

              s = fitness(n);
           
              if fitness(n) < sort_f(n)
               
                  x(index(n),:) = tmpx;
                      x(n,:)=x(index(n),:);
                      sort_f(n)=fitness(n);
                      y(n,:)=x(n,:);
               
                 end
                 if sort_f(n)

                       global_x=y(n,:);
                       global_fitness=sort_f(n); 

                 end
               
         end
       
  w(t)=wmax-(wmax-wmin)*rand;
  for i=(Nbest+1):N  

         for j=1:D
   v(i,j)=w(t).*v(i,j)+c1*rand.*(y(i,j)-x(i,j))+c2*rand.*(global_x(j)-x(i,j));
                  if v(i,j)>vmax
                       v(i,j)=vmax;
                  end
                  if v(i,j)                       v(i,j)=vmin;
                  end
   end
   for j=1:D 
    x(i,j)=x(i,j)+v(i,j);
   
                  if x(i,j)>xmax
                       x(i,j)=xmax;
                  end
                  if x(i,j)                       x(i,j)=xmin;
                  end
              end
  end

  for i=1:N 
   for j=1:hiddennum
    xwf(j,:)=x(i,((j-1)*indim+1):j*indim);
   end
   for m=1:outdim
    xwb(m,:)=x(i,(indim*hiddennum+1):(indim*hiddennum+hiddennum));
   end
   xb(i,:)=x(i,((indim+1)*hiddennum+1):D);
   xbf=xb(i,1:hiddennum)';
   xbb=xb(i,hiddennum+1:hiddennum+outdim)';

   net.IW{1,1}=xwf; 
   net.LW{2,1}=xwb; 
   net.b{1}=xbf;
   net.b{2}=xbb;
   Trainoutput=sim(net,Ptrain);
   train_outn=mapminmax('reverse',Trainoutput,AllSamOuts);
   Train_out=roundn(train_outn,-1); 
   %train_realerror=Train_out-AllSamOut;
   train_relativeerror = sum(abs((Train_out-AllSamOut)./AllSamOut))/length(AllSamOut);  
   fitness(i)=train_relativeerror;
          local_fit(i) = fitness(i);
          if local_fit(i)
               sort_f(i)=local_fit(i);
               y(i,:)=x(i,:);           
          end
          if sort_f(i)               global_x=y(i,:);
    global_fitness=sort_f(i);
          end
       
      end
     end
    fit_gen(t)=global_fitness;
end
fv=fit_gen(itmax);

for j=1:hiddennum
 xwf(j,:)=global_x(1,((j-1)*indim+1):j*indim);
end
for k=1:outdim
 xwb(k,:)=global_x(1,(indim*hiddennum+1):(indim*hiddennum+hiddennum));
end
xb(1,:)=global_x(1,((indim+1)*hiddennum+1):D);
xbf=xb(1,1:hiddennum)';
xbb=xb(1,hiddennum+1:hiddennum+outdim)';

net.IW{1,1}=xwf;  
net.LW{2,1}=xwb;
net.b{1}=xbf; 
net.b{2}=xbb;  
train_out=sim(net,Ptrain);
test_out=sim(net,Ptest);
test_outn=mapminmax('reverse',test_out,AllSamOuts); 
train_outn=mapminmax('reverse',train_out,AllSamOuts); 
Test_out=roundn(test_outn,-1); 
Train_out=roundn(train_outn,-1);

ALLInput=[AllSamOut,AllTestOut];
ALLOutput=[Train_out,Test_out];

train_abserror=Train_out-AllSamOut; 
test_abserror=Test_out-AllTestOut; 

trainRelativeError=sum(abs(train_abserror./AllSamOut))/length(AllSamOut); 
trainRMSE=sqrt(sum((train_abserror./AllSamOut).^2)/length(AllSamOut));

testRelativeError=sum(abs(test_abserror./AllTestOut))/length(AllTestOut);
testRMSE=sqrt(sum((test_abserror./AllTestOut).^2)/length(AllTestOut));

AllRelativeError=sum(abs((ALLInput-ALLOutput)./ALLInput))/length(ALLInput);
AllRMSE=sqrt(sum(((ALLInput-ALLOutput)./ALLInput).^2)/length(ALLInput));
